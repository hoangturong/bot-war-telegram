import logging
import os
import requests
import aiohttp
import wikipediaapi
import string
from functools import wraps
import threading
import asyncio
import psutil
from telegram.ext import Application, CommandHandler, MessageHandler, filters
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, InputFile, Document
from telegram.ext import Application, CommandHandler, MessageHandler, filters, CallbackContext, ContextTypes
from telegram.constants import ParseMode
from google_trans_new import google_translator
from PIL import Image, ImageDraw, ImageFont
from telegram import Update, ChatMember
from io import BytesIO
from telegram.ext import ContextTypes
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from telegram.error import BadRequest
import subprocess
from collections import defaultdict
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackContext
from telegram.ext import filters
from bs4 import BeautifulSoup
from telegram.ext import CallbackContext
from telegram import ChatMember
from deep_translator import GoogleTranslator
import json
import sys
import tempfile
import sqlite3
from concurrent.futures import ThreadPoolExecutor
import time
import random
from gtts import gTTS
from telethon import TelegramClient
from google_images_search import GoogleImagesSearch
import qrcode
import cohere
from typing import Dict
import asyncio
import aiohttp
from datetime import datetime, timedelta
from typing import List
from io import BytesIO
from telegram.ext import Application, CommandHandler, ContextTypes, MessageHandler, filters
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes
from telegram.ext import Application, CommandHandler, CallbackContext
import aiofiles
from aiogram import types

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

TOKEN_BOT = 'TOKEN CỦA M'
ADMIN_IDS = [6885521657] ID MÀY
GROUP_CHAT_ID = -1002161708184 ID CHAT CỦA M
start_time = time.time()
bot_active = True
YOUR_ADMIN_ID = 6885521657 ID MÀY
GOOGLE_MAPS_URL = "https://www.google.com/maps/search/?api=1&query="
WEATHER_API_KEY = "API CỦA M"
PEXELS_API_KEY = '2Dp7wkBq7Z12VXS0zLuVhDtniIamGGk6ldTzhX3FQ2Vzq0UWYDpBIkRi'
IMAGE_URL = "https://www.vietnamfineart.com.vn/anh-gai-xinh/anh-gai-ngon-moi-nhat/"
COHERE_API_KEY = 'API CỦA M'
co = cohere.Client(COHERE_API_KEY)

translator = GoogleTranslator(source='en', target='vi')
operations = ['+', '-']

import tracemalloc
tracemalloc.start()

async def on(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    global bot_active
    bot_active = True
    await context.bot.send_message(chat_id=update.effective_chat.id, text="🤖 HenryNET-BOT\nBot Đã Được Bật")

async def off(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    global bot_active
    bot_active = False
    await context.bot.send_message(chat_id=update.effective_chat.id, text="🤖 HenryNET-BOT\nBot Đã Được Tắt")

async def text_to_voice(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    text = ' '.join(context.args).strip()
    
    if not text:
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text='🤖 HenryNET-BOT\nUsage: /voice <Text>'
        )
        return

    temp_file_path = tempfile.mktemp(suffix='.mp3')
    try:
        tts = gTTS(text, lang='vi')
        tts.save(temp_file_path)

        with open(temp_file_path, 'rb') as audio_file:
            await context.bot.send_voice(chat_id=update.effective_chat.id, voice=audio_file)
    
    except Exception as e:
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text=f'🤖 HenryNET-BOT\nError Bot'
        )
    
    finally:
        if os.path.exists(temp_file_path):
            os.remove(temp_file_path)

async def start(update: Update, context: CallbackContext) -> None:
    welcome_message = (
        "<pre>"
        "╭───────────────⭓\n"
        "│ <b>● /henry:</b> Khỏi Chạy Bot\n"
        "╰───────────────⭓\n"
        "</pre>"
    )
    await context.bot.send_message(chat_id=update.effective_chat.id, text=welcome_message, parse_mode='HTML')

async def henry(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    welcome_message = (
        "<blockquote>"
        "<b><i>🐝 [HenryNET] 🐝</i></b>\n"
        "<b><i>🌟 [Lệnh Member] 🌟</i></b>\n"
        "<b> ● /rules: Điều Khoản Bot</b>\n"
        "<b> ● /admin: Infio Admin</b>\n"
        "<b> ● /check_ip: Check IP</b>\n"
        "<b> ● /thoitiet: Xem Thời Tiết</b>\n"
        "<b> ● /voice: Văn Bản Thành Giọng Nói</b>\n"
        "<b> ● /getcode: Get Code HTML Site</b>\n"
        "<b> ● /getid: Lấy ID Bài Viết</b>\n"
        "<b> ● /tiktokdl: Download TikTok</b>\n"
        "<b> ● /ai: Vẽ Ảnh Phong Cách AI</b>\n"
        "<b> ● /qr: Văn Bản Qua QR</b>\n"
        "<b> ● /chatgpt: Hỏi Đáp Từ AI</b>\n"
        "<b> ● /id_me: GET ID Account</b>\n"
        "<b> ● /sms: Attack SMS Free</b>\n"
        "<b> ● /dichvu: Dịch Vụ Của BOT</b>\n\n"
        "<b><i> 🌟 [Lệnh Của Admin] 🌟</i></b>\n"
        "<b> ● /war: War Ựa Nhau Với TV</b>\n"
        "<b> ● /trangthai: Xem Trạng Thái</b>\n"
        "<b> ● /on: Bật Khởi Động Bot</b>\n"
        "<b> ● /off: Tắt Tính Năng Bot</b>\n"
        "<b><i>🐝 [HenryNET] 🐝</i></b>\n"
        "</blockquote>"
    )
    await context.bot.send_message(chat_id=update.effective_chat.id, text=welcome_message, parse_mode='HTML')

async def rules(update: Update, context: CallbackContext) -> None:
    if not bot_active:
        await context.bot.send_message(
            chat_id=update.effective_chat.id, 
            text="🤖 HenryNET-BOT\nHenryNET Đang Tắt Hiện Các Thành Viên Không Thể Sử Dụng"
        )
        return
    
    rules_message = (
        "<pre>"
        "╭───────────────⭓\n"
        "│ ● 1. Không gây chiến. Độc hại\n"
        "│ ● 2. Không spam bot\n"
        "│ ● 3. Không chia sẻ thông tin\n"
        "│ ● 4. Không tấn công bot\n"
        "│ ● 5. Tôn trọng quyền riêng tư của người khác\n"
        "│ ● 6. Không sử dụng ngôn ngữ xúc phạm\n"
        "│ ● 7. Tránh làm tràn ngập cuộc trò chuyện\n"
        "│ ● 8. Không quảng cáo trái phép\n"
        "│ ● 9. Thực hiện theo hướng dẫn của quản trị viên\n"
        "│ ● 10. Báo cáo hoạt động đáng ngờ\n"
        "╰───────────────⭓\n"
        "</pre>"
    )
    await context.bot.send_message(
        chat_id=update.effective_chat.id, 
        text=rules_message, 
        parse_mode='HTML'
    )

async def admin(update: Update, context: CallbackContext) -> None:
    if not bot_active:
        await context.bot.send_message(
            chat_id=update.effective_chat.id, 
            text="🤖 HenryNET-BOT\nHenryNET Đang Tắt Hiện Các Thành Viên Không Thể Sử Dụng"
        )
        return
    
    admin_message = (
        "<pre>"
        "🤖 HenryNET-BOT\n"
        "╭───────────────⭓\n"
        "│ ● Admin: [t.me/henrynet206]\n"
        "│ ● Email: haibe20617@gmail.com\n"
        "╰───────────────⭓"
        "</pre>"
    )
    await context.bot.send_message(
        chat_id=update.effective_chat.id, 
        text=admin_message, 
        parse_mode='HTML'
    )

async def check_ip(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not bot_active:
        await context.bot.send_message(chat_id=update.effective_chat.id, text="🤖 HenryNET-BOT\nBot hiện đang tắt")
        return

    if len(context.args) == 0:
        await context.bot.send_message(chat_id=update.effective_chat.id, text="🤖 HenryNET-BOT\n🤖 Usage: /check_ip <IP>")
        return

    ip_address = context.args[0]
    api_url = f"https://ipinfo.io/{ip_address}/json"

    try:
        response = requests.get(api_url)
        data = response.json()

        if "bogon" in data:
            await context.bot.send_message(chat_id=update.effective_chat.id, text="🤖 HenryNET-BOT\n<b>IP Không Hợp Lệ</b>", parse_mode=ParseMode.HTML)
        else:
            ip_info = (
                f"<pre>"
                f"🤖 <b>HenryNET-BOT</b>\n\n"
                f"● <b>IP:</b> {data.get('ip', 'N/A')}\n"
                f"● <b>City:</b> {data.get('city', 'N/A')}\n"
                f"● <b>Region:</b> {data.get('region', 'N/A')}\n"
                f"● <b>Country:</b> {data.get('country', 'N/A')}\n"
                f"● <b>Location:</b> {data.get('loc', 'N/A')}\n"
                f"● <b>Org:</b> {data.get('org', 'N/A')}\n"
                f"● <b>Timezone:</b> {data.get('timezone', 'N/A')}"
                f"</pre>"
            )
            await context.bot.send_message(chat_id=update.effective_chat.id, text=ip_info, parse_mode=ParseMode.HTML)
    except requests.exceptions.RequestException:
        await context.bot.send_message(chat_id=update.effective_chat.id, text="🤖 HenryNET-BOT\n<b>Không thể Check IP</b>", parse_mode=ParseMode.HTML)

async def on(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if update.effective_user.id in ADMIN_IDS:
        global bot_active
        bot_active = True
        await context.bot.send_message(chat_id=update.effective_chat.id, text="🤖 HenryNET-BOT\n🤖 Bot đã được bật")
    else:
        await context.bot.send_message(chat_id=update.effective_chat.id, text="🤖 HenryNET-BOT\nBạn không có quyền thực hiện lệnh này.")

async def off(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if update.effective_user.id in ADMIN_IDS:
        global bot_active
        bot_active = False
        await context.bot.send_message(chat_id=update.effective_chat.id, text="🤖 HenryNET-BOT\n🤖 Bot đã bị tắt")
    else:
        await context.bot.send_message(chat_id=update.effective_chat.id, text="🤖 HenryNET-BOT\nBạn không có quyền thực hiện lệnh này.")

async def code(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not bot_active:
        await context.bot.send_message(chat_id=update.effective_chat.id, text="🤖 HenryNET-BOT\nHenryNET Đang Tắt Hiện Các Thành Viên Không Thể Sử Dụng")
        return

    if len(context.args) == 0:
        await context.bot.send_message(chat_id=update.effective_chat.id, text="🤖 HenryNET-BOT\n🤖 Usage: /code <URL>")
        return

    url = context.args[0]
    try:
        response = requests.get(url)
        response.raise_for_status()

        html_code = response.text
        filename = "SourceCode.txt"

        with open(filename, "w", encoding="utf-8") as file:
            file.write(html_code)

        with open(filename, "rb") as document:
            await context.bot.send_document(chat_id=update.effective_chat.id, document=document)

        os.remove(filename)

    except requests.exceptions.HTTPError as http_err:
        error_message = f""
        print(error_message)
        await context.bot.send_message(chat_id=update.effective_chat.id, text=error_message)
    except requests.exceptions.RequestException as req_err:
        error_message = f""
        print(error_message)
        await context.bot.send_message(chat_id=update.effective_chat.id, text=error_message)
    except Exception as e:
        error_message = f""
        print(error_message)
        await context.bot.send_message(chat_id=update.effective_chat.id, text=error_message)

def get_geocode(city_name):
    try:
        geocode_url = f"http://api.openweathermap.org/geo/1.0/direct?q={city_name}&limit=1&appid={WEATHER_API_KEY}"
        response = requests.get(geocode_url)
        data = response.json()
        if response.status_code == 200 and data:
            return data[0]['lat'], data[0]['lon']
        return None, None
    except Exception as e:
        logger.error(f"Error fetching geocode")
        return None, None

def get_weather_data(lat, lon):
    try:
        base_url = "http://api.openweathermap.org/data/2.5/weather?"
        complete_url = f"{base_url}appid={WEATHER_API_KEY}&lat={lat}&lon={lon}&units=metric"
        response = requests.get(complete_url)
        weather_data = response.json()
        return weather_data
    except Exception as e:
        logger.error(f"")
        return {}

def translate_weather_description(description):
    try:
        translator = Translator()
        return translator.translate(description, src='en', dest='vi').text
    except Exception as e:
        logger.error(f"Error translating description: {e}")
        return description

def format_weather_message(weather_data, city):
    try:
        if weather_data.get('cod') != 200:
            return f"Error: {weather_data.get('message', '❌ Không Tìm Thấy Vị Trí')}"
        
        country = weather_data['sys']['country']
        lat = weather_data['coord']['lat']
        lon = weather_data['coord']['lon']
        map_link = f"https://www.google.com/maps/search/?api=1&query={lat},{lon}"
        description = weather_data['weather'][0]['description']
        description_vn = translate_weather_description(description)
        
        temp = weather_data['main']['temp']
        feels_like = weather_data['main']['feels_like']
        temp_min = weather_data['main']['temp_min']
        temp_max = weather_data['main']['temp_max']
        
        pressure = weather_data['main']['pressure']
        humidity = weather_data['main']['humidity']
        cloudiness = weather_data['clouds']['all']
        wind_speed = weather_data['wind']['speed']
        wind_deg = weather_data['wind']['deg']

        uvi = None
        uvi_response = requests.get(f'https://api.openweathermap.org/data/2.5/uvi?lat={lat}&lon={lon}&appid={WEATHER_API_KEY}')
        if uvi_response.status_code == 200:
            uvi = uvi_response.json().get('value')

        aqi = None
        air_pollution_response = requests.get(f'http://api.openweathermap.org/data/2.5/air_pollution?lat={lat}&lon={lon}&appid={WEATHER_API_KEY}')
        if air_pollution_response.status_code == 200:
            aqi = air_pollution_response.json().get('list', [{}])[0].get('main', {}).get('aqi')

        precipitation = weather_data.get('rain', {}).get('1h', 0)
        precipitation_percentage = round(precipitation * 100, 2)  
        message = (
            f"<pre>"
            f"╭────⭓Thời Tiết\n"
            f"│🔆Thông Tin Thời Tiết ở {city}\n"
            f"│🌍 Thành phố: {city}\n"
            f"│🔗 Link bản đồ: <a href='{map_link}'>Xem bản đồ</a>\n"
            f"│☁️ Thời tiết: {description_vn}\n"
            f"│🌡 Nhiệt độ hiện tại: {temp}°C\n"
            f"│🌡️ Cảm giác như: {feels_like}°C\n"
            f"│🌡️ Nhiệt độ tối đa: {temp_max}°C\n"
            f"│🌡️ Nhiệt độ tối thiểu: {temp_min}°C\n"
            f"│🍃 Áp suất: {pressure} hPa\n"
            f"│🫧 Độ ẩm: {humidity}%\n"
            f"│☁️ Mức độ mây: {cloudiness}%\n"
            f"│🌬️ Tốc độ gió: {wind_speed} m/s\n"
            f"│🌐 Quốc gia: {country}\n"
            f"│🌬 Hướng gió: {wind_deg}°\n"
        )

        if uvi is not None:
            message += f"│☀️ Chỉ số UV: {uvi}\n"
        if aqi is not None:
            message += f"│🏭 Chất lượng không khí: {aqi}\n"
        if precipitation > 0:
            message += f"│🌧 Lượng mưa: {precipitation} mm\n"
            message += f"│🌧 Phần trăm lượng mưa: {precipitation_percentage}%\n"

        message += f"╰───────────── ⭐</pre>\n"
        return message
    except KeyError as e:
        logger.error(f"Error formatting weather message: {e}")
        return f"❌ Lỗi Nghiêm Trọng"

async def thoitiet(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not bot_active:
        await context.bot.send_message(chat_id=update.effective_chat.id, text="🤖 HenryNET-BOT\nHenryNET Đang Tắt Hiện Các Thành Viên Không Thể Sử Dụng")
        return

    try:
        if len(context.args) < 1:
            await update.message.reply_text("🤖 HenryNET-BOT\n🤖 Usage: /thoitiet <Tỉnh Thành>")
            return
        
        city_name = ' '.join(context.args).strip()
        lat, lon = get_geocode(city_name)
        
        if lat is not None and lon is not None:
            weather_data = get_weather_data(lat, lon)
            weather_message = format_weather_message(weather_data, city_name)
        else:
            weather_message = "❌ Không thể tìm thấy tọa độ cho thành phố này. Vui lòng kiểm tra lại tên thành phố."

        await update.message.reply_text(weather_message, parse_mode='HTML')
    except Exception as e:
        logger.error(f"Hard Target")
        await update.message.reply_text(f"Lỗi Máy Chủ")

async def getid(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not bot_active:
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text="🤖 HenryNET-BOT\nHenryNET Đang Tắt Hiện Các Thành Viên Không Thể Sử Dụng"
        )
        return

    if len(context.args) < 1:
        await update.message.reply_text(
            "🤖 HenryNET-BOT\n🤖 Usage: /getid <Link URL>"
        )
        return

    url = context.args[0]

    api_url = f"https://chongluadao.x10.bz/api/fb/getID.php?url={url}"
    try:
        response = requests.get(api_url)
        response.raise_for_status()
        data = response.json()

        if 'id' in data:
            content_type = 'không xác định'
            post_id = data['id']

            if '/posts/' in url or '/p/' in url:
                content_type = 'bài viết'
            elif '/profile.php' in url or 'www.facebook.com/' in url:
                content_type = 'trang cá nhân'

            reply_text = (
                f"╭─────⭓Lấy ID\n"
                f"│🆔 ID: {post_id}\n"
                f"╰─────────────⭓"
            )

            await update.message.reply_text(reply_text)
        else:
            await update.message.reply_text(
                "😔 Không thể lấy ID từ API. Vui lòng kiểm tra lại URL."
            )
    except requests.RequestException as e:
        await update.message.reply_text(
            f"😔 Error API"
        )

async def generate_qr(update: Update, context: CallbackContext):
    if not bot_active:
        await update.message.reply_text("🤖 HenryNET-BOT\nHenryNET Đang Tắt Hiện Các Thành Viên Không Thể Sử Dụng")
        return

    if context.args:
        input_text = ' '.join(context.args)
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(input_text)
        qr.make(fit=True)
        
        img = qr.make_image(fill='black', back_color='white')
        bio = BytesIO()
        bio.name = 'qr.png'
        img.save(bio, 'PNG')
        bio.seek(0)

        await update.message.reply_photo(photo=bio, caption=f"Qr Của Chữ: [{input_text}]")
    else:
        await update.message.reply_text("🤖 HenryNET-BOT\n🤖 Usage: /qr <Chữ Cần Làm>")

async def id_me(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not bot_active:
        await update.message.reply_text("🤖 HenryNET-BOT\nHenryNET Đang Tắt. Hiện Các Thành Viên Không Thể Sử Dụng")
        return

    user = update.message.from_user
    user_id = user.id
    username = user.username or "☄️ Chưa Có Tên"

    profile_photo = "🎉 Image: [Chưa có ảnh]"
    photos = await context.bot.get_user_profile_photos(user_id)
    if photos.total_count > 0:
        profile_photo = f"🎉 Image: {photos.photos[0][0].file_id}"

    bio = getattr(user, 'bio', "💤 Bio: [Chưa có tiểu sử]")

    response = (
        f"💎 ID: {user_id}\n"
        f"{bio}"
    )
    await context.bot.send_message(chat_id=update.message.chat_id, text=response)

async def chat(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not bot_active:
        await context.bot.send_message(chat_id=update.effective_chat.id, text="🤖 HenryNET-BOT\nHenryNET Đang Tắt Hiện Các Thành Viên Không Thể Sử Dụng")
        return

    if context.args:
        question = ' '.join(context.args)

        response = co.generate(
            model='command-xlarge-nightly',
            prompt=question,
            max_tokens=50
        )
        
        answer = response.generations[0].text.strip()
        await update.message.reply_text(answer)
    else:
        await update.message.reply_text('🤖 HenryNET-BOT\n🤖 Usage /chat <Câu Hỏi>')

async def trangthai(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if update.effective_user.id not in ADMIN_IDS:
        await update.message.reply_text("🤖 HenryNET-BOT\n💀 Bạn Không Có Quyền Thực Hiện Lệnh Này.")
        return

    uptime_seconds = int(time.time() - start_time)
    uptime = str(timedelta(seconds=uptime_seconds))

    cpu_usage = psutil.cpu_percent(interval=1)
    status_message = (
        f"🤖 HenryNET-BOT\n"
        f"⏳ UpTime: [{uptime}]\n"
        f"💻 CPU: [{cpu_usage}|%]\n"
    )

    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text=status_message
    )

async def ai(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not bot_active:
        await context.bot.send_message(chat_id=update.effective_chat.id, text="🤖 HenryNET-BOT\nHenryNET Đang Tắt Hiện Các Thành Viên Không Thể Sử Dụng")
        return

    if len(context.args) == 0:
        await update.message.reply_text(
            "🤖 HenryNET-BOT\nUsage: /ai <Mô Tả Ảnh>"
        )
        return
    
    prompt = ' '.join(context.args)

    response = requests.get(f"https://lexica.art/api/v1/search?q={prompt}")
    
    if response.status_code == 200:
        results = response.json().get('images', [])
        
        if results:
            selected_image = random.choice(results)
            image_url = selected_image['src']
            await context.bot.send_photo(
                chat_id=update.effective_chat.id,
                photo=image_url,
                caption=f"🤖 HenryNET-BOT\n🐇 Ảnh Của [{prompt}]"
            )
        else:
            await update.message.reply_text(
                "🤖 HenryNET-BOT\n❌ Không Có Ảnh."
            )
    else:
        await update.message.reply_text(
            "🤖 HenryNET-BOT\n❌ Server AI Timeout."
        )

last_sms_time = {}
async def sms(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not bot_active:
        await context.bot.send_message(chat_id=update.effective_chat.id, text="🤖 HenryNET-BOT\nHenryNET Đang Tắt Hiện Các Thành Viên Không Thể Sử Dụng")
        return

    user_id = update.effective_user.id
    username = update.effective_user.username or "Unknown User"

    if len(context.args) < 2:
        await update.message.reply_text(
            "🤖 HenryNET-BOT\nUsage: /sms <Phone> <Time>"
        )
        return

    phone = context.args[0]
    count = int(context.args[1])

    if not (phone.isdigit() and len(phone) == 10 and phone[0] == '0'):
        await update.message.reply_text("❌ Số Điện Thoại Phải Có 10 Số\n🦄 Bắt Đầu Từ Số 0")
        return

    if count < 1 or count > 20:
        await update.message.reply_text("📏 Min: [1] Max: [20]")
        return

    if user_id not in ADMIN_IDS:
        last_time = last_sms_time.get(user_id, 0)
        current_time = time.time()

        if current_time - last_time < 60:
            remaining_time = int(60 - (current_time - last_time))
            await update.message.reply_text(
                f"⏳ Vui Lòng Chờ {remaining_time} Giây Để Thực Hiện SPAM Tiếp Theo"
            )
            return

        last_sms_time[user_id] = current_time

    url = f"http://103.67.197.79:2006/api/sms?key=haibe&phone={phone}&count={count}"
    response = requests.get(url)

    if response.status_code == 200:
        result = response.json()
        if result.get('Status') == "[Successfully Sent SMS]":
            ext = f'''
<blockquote>
╭──────────────────⭓
│ 🤖 Henry-NET Spam 
│ 🚀 SPAM - SMS 🚀
│ ☀️ User: [@{username}]
│ ⚡ Phone: [{phone}]
│ ⌛ Time: [{count}]
│ 🎮 Plan: [VIP-SUPER]
│ 🧸 Admin: [@henrynet206]
╰──────────────────⭓
</blockquote>
<pre>
💠 10 Count Có Thể Spam 30 Phút
💨 Vui Lòng Hạn Chế Spam
</pre>
            '''
            await context.bot.send_message(
                chat_id=update.effective_chat.id,
                text=ext,
                parse_mode='HTML'
            )
        else:
            await context.bot.send_message(
                chat_id=update.effective_chat.id,
                text="❌ SMS Error"
            )
    else:
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text="❌ SMS Error"
        )

async def dichvu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not bot_active:
        await context.bot.send_message(chat_id=update.effective_chat.id, text="🤖 HenryNET-BOT\nBot Hiện Đang Tắt. Vui Lòng Thử Lại Sau.")
        return

    services_info = (
        f"<pre>"
        f"🤖 <b>HenryNET-BOT</b>\n\n"
        f"⚙️ <b>[Các Dịch Vụ]</b>\n\n"
        f" <b>Setup C2/API/Qbot:</b> Setup C2 API / Botnet.\n"
        f" <b>Tool DDoS:</b> Cung Cấp Tool DDoS Free.\n"
        f" <b>Lập Trình:</b> Code Web Theo Yêu Cầu\n"
        f" <b>Hỗ Trợ:</b> Hỗ Trợ Setup Termux - Pc - ISH\n"
        f"</pre>"
    )

    await context.bot.send_message(chat_id=update.effective_chat.id, text=services_info, parse_mode=ParseMode.HTML)

async def tiktokdl(update: Update, context: CallbackContext) -> None:
    if not bot_active:
        await context.bot.send_message(chat_id=update.effective_chat.id, text="🤖 HenryNET-BOT\nHenryNET Đang Tắt Hiện Các Thành Viên Không Thể Sử Dụng")
        return

    if len(context.args) == 0:
        await update.message.reply_text("🎬 [/tiktokdl <Link Video>] 🎬")
        return

    url = context.args[0]
    api_url = f"https://tikwm.com/api/?url={url}"

    await update.message.reply_text("💸 Đang GET Thông Tin Video 💸")

    try:
        response = requests.get(api_url)
        response.raise_for_status()

        data = response.json()

        if 'data' in data and 'play' in data['data']:
            video_url = data['data']['play']
            music_url = data['data'].get('music', '')
            title = data['data'].get('title', 'Video TikTok')
            nickname = data['data'].get('nickname', 'Unknown')

            video_response = requests.get(video_url)
            video_response.raise_for_status()
            video_file = InputFile(video_response.content, filename=f"{title}.mp4")

            message = (
                f"<b>🎬 Video Name:</b> <i>{title}</i>"
            )

            await update.message.reply_html(message)
            await update.message.reply_video(video_file, caption="🎬 Video Play 🎬")

        else:
            await update.message.reply_text("💸 Lỗi Server 💸")

    except requests.RequestException as e:
        await update.message.reply_text(f"💸 Lỗi Server 💸")   

async def handle_answer(update: Update, context: CallbackContext) -> None:
    pass

def load_war_messages():
    with open('war.txt', 'r', encoding='utf-8') as file:
        return file.readlines()

async def send_random_message(context, chat_id):
    messages = load_war_messages()
    if not messages:
        await context.bot.send_message(chat_id=chat_id, text="No messages available.")
        return
    message = random.choice(messages).strip()
    await context.bot.send_message(chat_id=chat_id, text=message)

async def war(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        await update.message.reply_text("🤖 HenryNET-BOT\n💀 Bạn Không Có Quyền Thực Hiện Lệnh Này.")
        return

    if len(context.args) != 2:
        await update.message.reply_text("Usage: /war <ID> <Count>")
        return

    target_id = int(context.args[0])
    try:
        count = int(context.args[1])
    except ValueError:
        await update.message.reply_text("🎶 Vui Lòng Nhập Số 🎶")
        return

    if count <= 0:
        await update.message.reply_text("🌞 Số Lần Là Chữ Số 🌞")
        return

    await update.message.reply_text("🔥 Đang Chuẩn Bị War Với Thằng Lồn Đó 🔥")
    for _ in range(count):
        await send_random_message(context, target_id)
        await asyncio.sleep(1)

def main() -> None:
    application = Application.builder().token(TOKEN_BOT).build()
    application.add_handler(CommandHandler('war', war))
    application.add_handler(CommandHandler('tiktokdl', tiktokdl))
    application.add_handler(CommandHandler('dichvu', dichvu))
    application.add_handler(CommandHandler('sms', sms))
    application.add_handler(CommandHandler('ai', ai))
    application.add_handler(CommandHandler('trangthai', trangthai))
    application.add_handler(CommandHandler('chatgpt', chat))
    application.add_handler(CommandHandler('id_me', id_me))
    application.add_handler(CommandHandler('qr', generate_qr))
    application.add_handler(CommandHandler('getid', getid))
    application.add_handler(CommandHandler("thoitiet", thoitiet))
    application.add_handler(CommandHandler("getcode", code))
    application.add_handler(CommandHandler("voice", text_to_voice))
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("henry", henry))
    application.add_handler(CommandHandler("rules", rules))
    application.add_handler(CommandHandler("admin", admin))
    application.add_handler(CommandHandler("check_ip", check_ip))
    application.add_handler(CommandHandler("on", on))
    application.add_handler(CommandHandler("off", off))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_answer))

    application.run_polling()

if __name__ == '__main__':
    asyncio.run(main())
    main()